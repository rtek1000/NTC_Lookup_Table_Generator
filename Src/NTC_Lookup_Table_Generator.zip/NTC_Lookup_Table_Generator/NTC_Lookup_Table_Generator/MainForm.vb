﻿'
' Created by SharpDevelop.
' User: User
' Date: 21/03/2023
' Time: 23:25
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System.Math
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions

Public Partial Class MainForm
	dim	tbxRes25deg_Text As String = ""
	dim	tbxBval_Text As String = ""
	dim	tbxR2val_Text As String = ""
	dim	tbxTmin_Text As String = ""
	dim	tbxTmax_Text As String = ""
	dim	tbxStep_Text As String = ""
	dim	tbxVref_Text As String = ""
	dim	tbxADCbits_Text As String = ""
	Dim	tbxResult_Text As String = ""
		
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	Sub BtnExitClick(sender As Object, e As EventArgs)
		Me.Close		
	End Sub
	
	Sub BtnResetClick(sender As Object, e As EventArgs)
		
		If BtnReset.Text = "Clear" Then
			BtnReset.Text = "Restore"
			
			tbxRes25deg_Text = tbxRes25deg.Text
			tbxBval_Text = tbxBval.Text
			tbxR2val_Text = tbxR2val.Text
			tbxTmin_Text = tbxTmin.Text
			tbxTmax_Text = tbxTmax.Text
			tbxStep_Text = tbxStep.Text
			tbxVref_Text = tbxVref.Text
			tbxADCbits_Text = tbxADCbits.Text
			tbxResult_Text = tbxResult.Text
			
			tbxRes25deg.Text = ""
			tbxBval.Text = ""
			tbxR2val.Text = ""
			tbxTmin.Text = ""
			tbxTmax.Text = ""
			tbxStep.Text = ""
			tbxVref.Text = ""
			tbxADCbits.Text = ""
			tbxResult.Text = ""
		Else
			BtnReset.Text = "Clear"
			tbxRes25deg.Text = tbxRes25deg_Text
			tbxBval.Text = tbxBval_Text
			tbxR2val.Text = tbxR2val_Text
			tbxTmin.Text = tbxTmin_Text
			tbxTmax.Text = tbxTmax_Text
			tbxStep.Text = tbxStep_Text
			tbxVref.Text = tbxVref_Text
			tbxADCbits.Text = tbxADCbits_Text
			tbxResult.Text = tbxResult_Text
		End If
		
		progressBar1.Value = progressBar1.Minimum
	End Sub
	
	Sub BtnCopyClick(sender As Object, e As EventArgs)
		If tbxResult.Text <> "" Then
		    tbxResult.Focus
		
		    tbxResult.SelectAll
		
			My.Computer.Clipboard.SetText(tbxResult.Text)
		Else
			MsgBox("Please click the Generate button")
		End If
		
		progressBar1.Value = progressBar1.Minimum
	End Sub
	
	Sub BtnGenClick(sender As Object, e As EventArgs)
		Dim maxStep As Integer
		Dim temperature As Double
		
		If tbxRes25deg.Text = "" Then
			MsgBox("Please insert Resistance at 25°C")
			tbxRes25deg.Focus
			Return
		End If
		
		If tbxBval.Text = "" Then
			MsgBox("Please insert NTC Beta value (B)")
			tbxBval.Focus
			Return
		End If
		
		If tbxR2val.Text = "" Then
			MsgBox("Please insert R2 resistance")
			tbxR2val.Focus
			Return
		End If
		
		If tbxTmin.Text = "" Then
			MsgBox("Please insert Minimum Temperature (°C)")
			tbxTmin.Focus
			Return
		End If
		
		If tbxTmax.Text = "" Then
			MsgBox("Please insert Maximum Temperature (°C)")
			tbxTmax.Focus
			Return
		End If
		
		If tbxStep.Text = "" Then
			MsgBox("Please insert Degree Step")
			tbxStep.Focus
			Return
		End If
		
		If tbxVref.Text = "" Then
			MsgBox("Please insert ADC voltage reference")
			tbxVref.Focus
			Return
		End If
		
		If tbxADCbits.Text = "" Then
			MsgBox("Please insert ADC bits")
			tbxADCbits.Focus
			Return
		End If
		
		If Val(tbxTmin.Text) >= (Val(tbxTmax.Text) - Val(tbxStep.Text)) Then
			MsgBox("Please insert Tmax > Tmin")
			tbxTmin.Focus
			Return
		End If
		
		BtnReset.Text = "Clear"
		
		pictureBox1.Visible = False
		tbxResult.Visible = True
		
		Try
			Dim file1 As System.IO.StreamWriter
			Dim filePath As String = Application.StartupPath & "\app.ini"
			
			file1 = My.Computer.FileSystem.OpenTextFileWriter(filePath, False)
			file1.WriteLine(tbxRes25deg.Text)
			file1.WriteLine(tbxBval.Text)
			file1.WriteLine(tbxR2val.Text)
			file1.WriteLine(tbxTmin.Text)
			file1.WriteLine(tbxTmax.Text)
			file1.WriteLine(tbxStep.Text)
			file1.WriteLine(tbxVref.Text)
			file1.WriteLine(tbxADCbits.Text)
			file1.WriteLine(cbxArrayLength.Checked.ToString)
			file1.Flush()
			file1.Close()
			file1.Dispose()
		Catch exc As Exception
			MsgBox("Error: " & exc.Message)
		End Try
		
		maxStep = CInt((Val(tbxTmax.Text) - Val(tbxTmin.Text)) / Val(tbxStep.Text)) + 1
		
		progressBar1.Value = progressBar1.Minimum
		
		Dim result As Integer = MsgBox("Array length: " & _
			maxStep.ToString, MsgBoxStyle.OkCancel)
		
		If result = vbCancel Then
			Return
		End If
		
		'MsgBox("e^1: " & Exp(1))
		
		temperature = Val(tbxTmin.Text)
		
		tbxResult.Text = ""
		
		Dim strTmp As String = ""
		
		If cbxArrayLength.Checked = True Then
			strTmp = "Array length: " & maxStep.ToString & vbCrLf & vbCrLf
		End If
		
		strTmp = strTmp & calc_resistance(temperature).ToString
		
		For i As Integer = 1 To maxStep - 1
			temperature = (i * Val(tbxStep.Text)) + Val(tbxTmin.Text)
			'MsgBox("temperature: " & temperature.ToString)
			strTmp = strTmp & ", " & calc_resistance(temperature).ToString
			
			progressBar1.Value = CInt((i / maxStep) * 100)
		Next
		
		tbxResult.MaxLength = strTmp.Length
		
		If strTmp.Length > tbxResult.MaxLength Then
			MsgBox("Error. Max Length acheived: " & tbxResult.MaxLength.ToString & _
				" > " & strTmp.Length.ToString)
		End If
		
		tbxResult.Text = strTmp
		
		progressBar1.Value = 100
		
		tbxResult.Focus
		
		tbxResult.SelectAll
	End Sub
	
	Function calc_resistance (Temper1 As Double) As Integer
		Dim resistance As Double
		Dim result As Integer
		Dim R25 As Double = Val(tbxRes25deg.Text)
		Dim Beta As Double = Val(tbxBval.Text)
		Dim Temper0 As Double = 25.0
		
		Dim part1 As Double = (Temper1 + 273.15) * (Temper0 + 273.15)
		Dim part2 As Double = (Temper1 + 273.15001) - (Temper0 + 273.15)
		Dim part3 As Double = part1 / part2
		Dim part4 As Double = Beta / part3
		Dim part5 As Double = Exp(part4)
		
		resistance = R25 / part5
		
		Dim part6 As Double = Val(tbxR2val.Text) + resistance
		Dim part7 As Double = resistance / part6
		Dim part8 As Double = part7 * Val(tbxVref.Text)
		Dim part9 As Double = part8 * (2 ^ Val(tbxADCbits.Text))
		Dim part10 As Double = part9 / Val(tbxVref.Text)
		
		result = CInt(part10)
		
		Return result
	End Function
	
	Sub BtnSaveClick(sender As Object, e As EventArgs)
        Dim myStream As Stream
        Dim saveFileDialog1 As New SaveFileDialog()
        
        If tbxResult.Text <> "" Then
		    tbxResult.Focus
		
		    tbxResult.SelectAll
		Else
			MsgBox("Please click the Generate button")
			
			Return
		End If

        saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        saveFileDialog1.FilterIndex = 2
        saveFileDialog1.RestoreDirectory = True
        saveFileDialog1.FileName = "NTC_Array_Lookup.txt"

        If saveFileDialog1.ShowDialog() = DialogResult.OK Then
            myStream = saveFileDialog1.OpenFile()
            If (myStream IsNot Nothing) Then
            	Dim bytes As Byte() = System.Text.Encoding.Unicode.GetBytes(tbxResult.Text)
            	myStream.Write(bytes, 0, bytes.Length)
            	myStream.Flush
            	myStream.Close()
            	myStream.Dispose()
            End If
        End If	
        
        progressBar1.Value = progressBar1.Minimum
	End Sub
	
	Sub MainFormLoad(sender As Object, e As EventArgs)
		Try
			If My.Computer.FileSystem.FileExists(Application.StartupPath & "\app.ini") Then				
				Dim file As System.IO.StreamReader
				file = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\app.ini")
				tbxRes25deg.Text = Val(file.ReadLine).ToString
				tbxBval.Text = Val(file.ReadLine).ToString
				tbxR2val.Text = Val(file.ReadLine).ToString
				tbxTmin.Text = Val(file.ReadLine).ToString
				tbxTmax.Text = Val(file.ReadLine).ToString
				tbxStep.Text = Val(file.ReadLine).ToString
				tbxVref.Text = Val(file.ReadLine).ToString
				tbxADCbits.Text = Val(file.ReadLine).ToString
				
				If file.ReadLine = "False" Then
					cbxArrayLength.Checked = False
				Else
					cbxArrayLength.Checked = True
				End If
				
				file.Close()
			End If
		Catch exc As Exception
			MsgBox("Error: " & exc.Message)
		End Try	
	End Sub
	
	Sub PictureBox1Click(sender As Object, e As EventArgs)
		Dim result As Integer
		Dim url As String = "https://github.com/mister-grumbler/w1209-firmware"
		Dim msg1 As String = "Check adc.c file: const unsigned int rawAdc[]"
		
		result = MsgBox("Go to: " & url & vbCrLf & vbCrLf & msg1, MsgBoxStyle.OkCancel)
		
		If result = vbOK Then
			Process.Start(url)
		End If
	End Sub

	Sub TbxRes25degTextChanged(sender As Object, e As EventArgs)

	End Sub
	
	Sub TbxRes25degKeyPress(sender As Object, e As KeyPressEventArgs)
		If Not Char.IsNumber(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
	        e.Handled = True
    	End If
	End Sub
	
	Sub TbxBvalTextChanged(sender As Object, e As EventArgs)

	End Sub
	
	Sub TbxBvalKeyPress(sender As Object, e As KeyPressEventArgs)
		If Not Char.IsNumber(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
	        e.Handled = True
    	End If
	End Sub
	
	Sub TbxR2valTextChanged(sender As Object, e As EventArgs)

	End Sub
	
	Sub TbxR2valKeyPress(sender As Object, e As KeyPressEventArgs)
		If Not Char.IsNumber(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
	        e.Handled = True
    	End If
	End Sub
	
	Sub TbxTminTextChanged(sender As Object, e As EventArgs)
		If TbxTmin.Text.IndexOf("-") > 0 Then
			TbxTmin.Text = TbxTmin.Text.Replace("-", "")
		End If
	End Sub
	
	Sub TbxTminKeyPress(sender As Object, e As KeyPressEventArgs)
		If Not Char.IsNumber(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) _
			AndAlso Not e.KeyChar = "." AndAlso Not e.keyChar = "-" Then
	        e.Handled = True
		End If
		
		If e.KeyChar = "." And TbxTmin.Text.Contains(".") Then
			e.Handled = True
		End If
		
		If e.KeyChar = "-" And TbxTmin.Text.Contains("-") Then
			e.Handled = True
		End If
	End Sub
	
	Sub TbxTmaxTextChanged(sender As Object, e As EventArgs)
		If TbxTmax.Text.IndexOf("-") > 0 Then
			TbxTmax.Text = TbxTmax.Text.Replace("-", "")
		End If
	End Sub
	
	Sub TbxTmaxKeyPress(sender As Object, e As KeyPressEventArgs)
		If Not Char.IsNumber(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) _
			AndAlso Not e.KeyChar = "." AndAlso Not e.keyChar = "-" Then
	        e.Handled = True
		End If
		
		If e.KeyChar = "." And TbxTmax.Text.Contains(".") Then
			e.Handled = True
		End If
		
		If e.KeyChar = "-" And TbxTmax.Text.Contains("-") Then
			e.Handled = True
		End If
	End Sub
	
	Sub TbxStepTextChanged(sender As Object, e As EventArgs)

	End Sub
	
	Sub TbxStepKeyPress(sender As Object, e As KeyPressEventArgs)
		If Not Char.IsNumber(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) _
			AndAlso Not e.KeyChar = "." Then	
	        e.Handled = True
		End If
		
		If e.KeyChar = "." And TbxStep.Text.Contains(".") Then
			e.Handled = True
		End If
	End Sub
	
	Sub TbxVrefTextChanged(sender As Object, e As EventArgs)

	End Sub
	
	Sub TbxVrefKeyPress(sender As Object, e As KeyPressEventArgs)
		If Not Char.IsNumber(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) _
			AndAlso Not e.keyChar = "." Then
	        e.Handled = True
		End If
		
		If e.KeyChar = "." And TbxVref.Text.Contains(".") Then
			e.Handled = True
		End If
	End Sub
	
	Sub TbxADCbitsTextChanged(sender As Object, e As EventArgs)

	End Sub
	
	Sub TbxADCbitsKeyPress(sender As Object, e As KeyPressEventArgs)
		If Not Char.IsNumber(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
	        e.Handled = True
    	End If
	End Sub
	
	Sub BtnShowImageClick(sender As Object, e As EventArgs)
		If My.Computer.FileSystem.FileExists(Application.StartupPath & "\image.jpg") Then		
			PictureBox1.Image = Image.FromFile(Application.StartupPath & "\image.jpg")
		Else
			MsgBox("Image not found: " & Application.StartupPath & "\image.jpg")
		End If
		
		If pictureBox1.Visible = False Then
			pictureBox1.Visible = True
			tbxResult.Visible = False
		Else
			pictureBox1.Visible = False
			tbxResult.Visible = True
		End If
		
		progressBar1.Value = progressBar1.Minimum
	End Sub
End Class
