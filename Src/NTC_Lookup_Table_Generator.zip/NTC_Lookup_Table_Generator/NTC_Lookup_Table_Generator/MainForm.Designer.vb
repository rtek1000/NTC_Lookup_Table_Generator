﻿'
' Created by SharpDevelop.
' User: User
' Date: 21/03/2023
' Time: 23:25
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class MainForm
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.btnGen = New System.Windows.Forms.Button()
		Me.btnCopy = New System.Windows.Forms.Button()
		Me.btnExit = New System.Windows.Forms.Button()
		Me.label1 = New System.Windows.Forms.Label()
		Me.tbxRes25deg = New System.Windows.Forms.TextBox()
		Me.label2 = New System.Windows.Forms.Label()
		Me.tbxBval = New System.Windows.Forms.TextBox()
		Me.pictureBox1 = New System.Windows.Forms.PictureBox()
		Me.label3 = New System.Windows.Forms.Label()
		Me.tbxR2val = New System.Windows.Forms.TextBox()
		Me.tbxResult = New System.Windows.Forms.TextBox()
		Me.label4 = New System.Windows.Forms.Label()
		Me.tbxTmin = New System.Windows.Forms.TextBox()
		Me.tbxTmax = New System.Windows.Forms.TextBox()
		Me.label5 = New System.Windows.Forms.Label()
		Me.label6 = New System.Windows.Forms.Label()
		Me.tbxStep = New System.Windows.Forms.TextBox()
		Me.label7 = New System.Windows.Forms.Label()
		Me.btnReset = New System.Windows.Forms.Button()
		Me.toolTip1 = New System.Windows.Forms.ToolTip(Me.components)
		Me.btnShowImage = New System.Windows.Forms.Button()
		Me.btnSave = New System.Windows.Forms.Button()
		Me.tbxVref = New System.Windows.Forms.TextBox()
		Me.label8 = New System.Windows.Forms.Label()
		Me.tbxADCbits = New System.Windows.Forms.TextBox()
		Me.label9 = New System.Windows.Forms.Label()
		Me.cbxArrayLength = New System.Windows.Forms.CheckBox()
		Me.saveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
		Me.progressBar1 = New System.Windows.Forms.ProgressBar()
		Me.label10 = New System.Windows.Forms.Label()
		CType(Me.pictureBox1,System.ComponentModel.ISupportInitialize).BeginInit
		Me.SuspendLayout
		'
		'btnGen
		'
		Me.btnGen.Location = New System.Drawing.Point(495, 9)
		Me.btnGen.Name = "btnGen"
		Me.btnGen.Size = New System.Drawing.Size(125, 59)
		Me.btnGen.TabIndex = 0
		Me.btnGen.Text = "Generate"
		Me.btnGen.UseVisualStyleBackColor = true
		AddHandler Me.btnGen.Click, AddressOf Me.BtnGenClick
		'
		'btnCopy
		'
		Me.btnCopy.Location = New System.Drawing.Point(495, 139)
		Me.btnCopy.Name = "btnCopy"
		Me.btnCopy.Size = New System.Drawing.Size(125, 58)
		Me.btnCopy.TabIndex = 1
		Me.btnCopy.Text = "Copy (Ctrl+C)"
		Me.btnCopy.UseVisualStyleBackColor = true
		AddHandler Me.btnCopy.Click, AddressOf Me.BtnCopyClick
		'
		'btnExit
		'
		Me.btnExit.Location = New System.Drawing.Point(495, 382)
		Me.btnExit.Name = "btnExit"
		Me.btnExit.Size = New System.Drawing.Size(125, 59)
		Me.btnExit.TabIndex = 2
		Me.btnExit.Text = "Exit"
		Me.btnExit.UseVisualStyleBackColor = true
		AddHandler Me.btnExit.Click, AddressOf Me.BtnExitClick
		'
		'label1
		'
		Me.label1.Location = New System.Drawing.Point(12, 12)
		Me.label1.Name = "label1"
		Me.label1.Size = New System.Drawing.Size(193, 21)
		Me.label1.TabIndex = 3
		Me.label1.Text = "NTC (RT) Resistance at 25°C (Ohms):"
		'
		'tbxRes25deg
		'
		Me.tbxRes25deg.Location = New System.Drawing.Point(211, 9)
		Me.tbxRes25deg.Name = "tbxRes25deg"
		Me.tbxRes25deg.Size = New System.Drawing.Size(97, 20)
		Me.tbxRes25deg.TabIndex = 4
		Me.tbxRes25deg.Text = "10000"
		Me.toolTip1.SetToolTip(Me.tbxRes25deg, "Nominal resistance at 25 °C")
		AddHandler Me.tbxRes25deg.TextChanged, AddressOf Me.TbxRes25degTextChanged
		AddHandler Me.tbxRes25deg.KeyPress, AddressOf Me.TbxRes25degKeyPress
		'
		'label2
		'
		Me.label2.Location = New System.Drawing.Point(12, 38)
		Me.label2.Name = "label2"
		Me.label2.Size = New System.Drawing.Size(177, 21)
		Me.label2.TabIndex = 5
		Me.label2.Text = "NTC (RT) Beta value (B):"
		'
		'tbxBval
		'
		Me.tbxBval.AutoCompleteCustomSource.AddRange(New String() {"3380", "3435", "3500", "3575", "3892", "3950", "3974", "3984"})
		Me.tbxBval.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.tbxBval.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.RecentlyUsedList
		Me.tbxBval.Location = New System.Drawing.Point(211, 35)
		Me.tbxBval.Name = "tbxBval"
		Me.tbxBval.Size = New System.Drawing.Size(97, 20)
		Me.tbxBval.TabIndex = 6
		Me.tbxBval.Text = "3950"
		Me.toolTip1.SetToolTip(Me.tbxBval, "Beta: relationship between resistance and temperature of an NTC thermistor")
		AddHandler Me.tbxBval.TextChanged, AddressOf Me.TbxBvalTextChanged
		AddHandler Me.tbxBval.KeyPress, AddressOf Me.TbxBvalKeyPress
		'
		'pictureBox1
		'
		Me.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
		Me.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.pictureBox1.InitialImage = Nothing
		Me.pictureBox1.Location = New System.Drawing.Point(12, 140)
		Me.pictureBox1.Name = "pictureBox1"
		Me.pictureBox1.Size = New System.Drawing.Size(472, 301)
		Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
		Me.pictureBox1.TabIndex = 7
		Me.pictureBox1.TabStop = false
		Me.toolTip1.SetToolTip(Me.pictureBox1, ""&Global.Microsoft.VisualBasic.ChrW(10)&Global.Microsoft.VisualBasic.ChrW(10)&Global.Microsoft.VisualBasic.ChrW(10)&"Source: https://github.com/mister-grumbler/w1209-firmware/blob/master/docs/the"& _ 
				"rmostat-w1209.jpg"&Global.Microsoft.VisualBasic.ChrW(10))
		Me.pictureBox1.Visible = false
		AddHandler Me.pictureBox1.Click, AddressOf Me.PictureBox1Click
		'
		'label3
		'
		Me.label3.Location = New System.Drawing.Point(12, 64)
		Me.label3.Name = "label3"
		Me.label3.Size = New System.Drawing.Size(177, 21)
		Me.label3.TabIndex = 8
		Me.label3.Text = "Resistor (R2) Resistance (Ohms):"
		'
		'tbxR2val
		'
		Me.tbxR2val.Location = New System.Drawing.Point(211, 61)
		Me.tbxR2val.Name = "tbxR2val"
		Me.tbxR2val.Size = New System.Drawing.Size(97, 20)
		Me.tbxR2val.TabIndex = 9
		Me.tbxR2val.Text = "20000"
		AddHandler Me.tbxR2val.TextChanged, AddressOf Me.TbxR2valTextChanged
		AddHandler Me.tbxR2val.KeyPress, AddressOf Me.TbxR2valKeyPress
		'
		'tbxResult
		'
		Me.tbxResult.BackColor = System.Drawing.SystemColors.ActiveCaptionText
		Me.tbxResult.Location = New System.Drawing.Point(12, 140)
		Me.tbxResult.Multiline = true
		Me.tbxResult.Name = "tbxResult"
		Me.tbxResult.ReadOnly = true
		Me.tbxResult.Size = New System.Drawing.Size(472, 301)
		Me.tbxResult.TabIndex = 10
		'
		'label4
		'
		Me.label4.Location = New System.Drawing.Point(340, 13)
		Me.label4.Name = "label4"
		Me.label4.Size = New System.Drawing.Size(67, 21)
		Me.label4.TabIndex = 11
		Me.label4.Text = "Tmin (°C):"
		'
		'tbxTmin
		'
		Me.tbxTmin.Location = New System.Drawing.Point(413, 9)
		Me.tbxTmin.Name = "tbxTmin"
		Me.tbxTmin.Size = New System.Drawing.Size(71, 20)
		Me.tbxTmin.TabIndex = 12
		Me.tbxTmin.Text = "-52"
		AddHandler Me.tbxTmin.TextChanged, AddressOf Me.TbxTminTextChanged
		AddHandler Me.tbxTmin.KeyPress, AddressOf Me.TbxTminKeyPress
		'
		'tbxTmax
		'
		Me.tbxTmax.Location = New System.Drawing.Point(413, 35)
		Me.tbxTmax.Name = "tbxTmax"
		Me.tbxTmax.Size = New System.Drawing.Size(71, 20)
		Me.tbxTmax.TabIndex = 14
		Me.tbxTmax.Text = "112"
		AddHandler Me.tbxTmax.TextChanged, AddressOf Me.TbxTmaxTextChanged
		AddHandler Me.tbxTmax.KeyPress, AddressOf Me.TbxTmaxKeyPress
		'
		'label5
		'
		Me.label5.Location = New System.Drawing.Point(340, 39)
		Me.label5.Name = "label5"
		Me.label5.Size = New System.Drawing.Size(67, 21)
		Me.label5.TabIndex = 13
		Me.label5.Text = "Tmax (°C):"
		'
		'label6
		'
		Me.label6.Location = New System.Drawing.Point(340, 64)
		Me.label6.Name = "label6"
		Me.label6.Size = New System.Drawing.Size(67, 21)
		Me.label6.TabIndex = 15
		Me.label6.Text = "Step (°C):"
		'
		'tbxStep
		'
		Me.tbxStep.Location = New System.Drawing.Point(413, 60)
		Me.tbxStep.Name = "tbxStep"
		Me.tbxStep.Size = New System.Drawing.Size(71, 20)
		Me.tbxStep.TabIndex = 16
		Me.tbxStep.Text = "1.0"
		AddHandler Me.tbxStep.TextChanged, AddressOf Me.TbxStepTextChanged
		AddHandler Me.tbxStep.KeyPress, AddressOf Me.TbxStepKeyPress
		'
		'label7
		'
		Me.label7.Location = New System.Drawing.Point(12, 111)
		Me.label7.Name = "label7"
		Me.label7.Size = New System.Drawing.Size(59, 21)
		Me.label7.TabIndex = 17
		Me.label7.Text = "Result:"
		'
		'btnReset
		'
		Me.btnReset.Location = New System.Drawing.Point(495, 74)
		Me.btnReset.Name = "btnReset"
		Me.btnReset.Size = New System.Drawing.Size(125, 59)
		Me.btnReset.TabIndex = 18
		Me.btnReset.Text = "Clear"
		Me.btnReset.UseVisualStyleBackColor = true
		AddHandler Me.btnReset.Click, AddressOf Me.BtnResetClick
		'
		'btnShowImage
		'
		Me.btnShowImage.Location = New System.Drawing.Point(495, 267)
		Me.btnShowImage.Name = "btnShowImage"
		Me.btnShowImage.Size = New System.Drawing.Size(125, 59)
		Me.btnShowImage.TabIndex = 27
		Me.btnShowImage.Text = "Load Image"
		Me.toolTip1.SetToolTip(Me.btnShowImage, "image.jpg")
		Me.btnShowImage.UseVisualStyleBackColor = true
		AddHandler Me.btnShowImage.Click, AddressOf Me.BtnShowImageClick
		'
		'btnSave
		'
		Me.btnSave.Location = New System.Drawing.Point(495, 203)
		Me.btnSave.Name = "btnSave"
		Me.btnSave.Size = New System.Drawing.Size(125, 58)
		Me.btnSave.TabIndex = 19
		Me.btnSave.Text = "Save As"
		Me.btnSave.UseVisualStyleBackColor = true
		AddHandler Me.btnSave.Click, AddressOf Me.BtnSaveClick
		'
		'tbxVref
		'
		Me.tbxVref.Location = New System.Drawing.Point(413, 86)
		Me.tbxVref.Name = "tbxVref"
		Me.tbxVref.Size = New System.Drawing.Size(71, 20)
		Me.tbxVref.TabIndex = 21
		Me.tbxVref.Text = "5.0"
		AddHandler Me.tbxVref.TextChanged, AddressOf Me.TbxVrefTextChanged
		AddHandler Me.tbxVref.KeyPress, AddressOf Me.TbxVrefKeyPress
		'
		'label8
		'
		Me.label8.Location = New System.Drawing.Point(340, 90)
		Me.label8.Name = "label8"
		Me.label8.Size = New System.Drawing.Size(67, 21)
		Me.label8.TabIndex = 20
		Me.label8.Text = "Vref (ADC):"
		'
		'tbxADCbits
		'
		Me.tbxADCbits.Location = New System.Drawing.Point(413, 112)
		Me.tbxADCbits.Name = "tbxADCbits"
		Me.tbxADCbits.Size = New System.Drawing.Size(71, 20)
		Me.tbxADCbits.TabIndex = 23
		Me.tbxADCbits.Text = "10"
		AddHandler Me.tbxADCbits.TextChanged, AddressOf Me.TbxADCbitsTextChanged
		AddHandler Me.tbxADCbits.KeyPress, AddressOf Me.TbxADCbitsKeyPress
		'
		'label9
		'
		Me.label9.Location = New System.Drawing.Point(340, 116)
		Me.label9.Name = "label9"
		Me.label9.Size = New System.Drawing.Size(67, 21)
		Me.label9.TabIndex = 22
		Me.label9.Text = "ADC bits:"
		'
		'cbxArrayLength
		'
		Me.cbxArrayLength.Location = New System.Drawing.Point(211, 87)
		Me.cbxArrayLength.Name = "cbxArrayLength"
		Me.cbxArrayLength.Size = New System.Drawing.Size(97, 20)
		Me.cbxArrayLength.TabIndex = 24
		Me.cbxArrayLength.Text = "Add Length"
		Me.cbxArrayLength.UseVisualStyleBackColor = true
		'
		'progressBar1
		'
		Me.progressBar1.Location = New System.Drawing.Point(72, 111)
		Me.progressBar1.Name = "progressBar1"
		Me.progressBar1.Size = New System.Drawing.Size(236, 17)
		Me.progressBar1.Step = 5
		Me.progressBar1.TabIndex = 25
		'
		'label10
		'
		Me.label10.ForeColor = System.Drawing.SystemColors.ControlDark
		Me.label10.Location = New System.Drawing.Point(495, 346)
		Me.label10.Name = "label10"
		Me.label10.Size = New System.Drawing.Size(125, 21)
		Me.label10.TabIndex = 26
		Me.label10.Text = "by RTEK1000 - 2023"
		Me.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'MainForm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(632, 453)
		Me.ControlBox = false
		Me.Controls.Add(Me.btnShowImage)
		Me.Controls.Add(Me.label10)
		Me.Controls.Add(Me.progressBar1)
		Me.Controls.Add(Me.cbxArrayLength)
		Me.Controls.Add(Me.tbxADCbits)
		Me.Controls.Add(Me.label9)
		Me.Controls.Add(Me.tbxVref)
		Me.Controls.Add(Me.label8)
		Me.Controls.Add(Me.btnSave)
		Me.Controls.Add(Me.btnReset)
		Me.Controls.Add(Me.label7)
		Me.Controls.Add(Me.tbxStep)
		Me.Controls.Add(Me.label6)
		Me.Controls.Add(Me.tbxTmax)
		Me.Controls.Add(Me.label5)
		Me.Controls.Add(Me.tbxTmin)
		Me.Controls.Add(Me.label4)
		Me.Controls.Add(Me.tbxR2val)
		Me.Controls.Add(Me.label3)
		Me.Controls.Add(Me.tbxBval)
		Me.Controls.Add(Me.label2)
		Me.Controls.Add(Me.tbxRes25deg)
		Me.Controls.Add(Me.label1)
		Me.Controls.Add(Me.btnExit)
		Me.Controls.Add(Me.btnCopy)
		Me.Controls.Add(Me.btnGen)
		Me.Controls.Add(Me.tbxResult)
		Me.Controls.Add(Me.pictureBox1)
		Me.MaximizeBox = false
		Me.Name = "MainForm"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "NTC Lookup Table Generator (for XH W1209 - Custom firmware)"
		AddHandler Load, AddressOf Me.MainFormLoad
		CType(Me.pictureBox1,System.ComponentModel.ISupportInitialize).EndInit
		Me.ResumeLayout(false)
		Me.PerformLayout
	End Sub
	Private btnShowImage As System.Windows.Forms.Button
	Private label10 As System.Windows.Forms.Label
	Private progressBar1 As System.Windows.Forms.ProgressBar
	Private saveFileDialog1 As System.Windows.Forms.SaveFileDialog
	Private cbxArrayLength As System.Windows.Forms.CheckBox
	Private tbxADCbits As System.Windows.Forms.TextBox
	Private label9 As System.Windows.Forms.Label
	Private tbxVref As System.Windows.Forms.TextBox
	Private label8 As System.Windows.Forms.Label
	Private btnSave As System.Windows.Forms.Button
	Private toolTip1 As System.Windows.Forms.ToolTip
	Private btnReset As System.Windows.Forms.Button
	Private label7 As System.Windows.Forms.Label
	Private tbxStep As System.Windows.Forms.TextBox
	Private label6 As System.Windows.Forms.Label
	Private label5 As System.Windows.Forms.Label
	Private tbxTmax As System.Windows.Forms.TextBox
	Private tbxTmin As System.Windows.Forms.TextBox
	Private label4 As System.Windows.Forms.Label
	Private tbxResult As System.Windows.Forms.TextBox
	Private tbxR2val As System.Windows.Forms.TextBox
	Private label3 As System.Windows.Forms.Label
	Private pictureBox1 As System.Windows.Forms.PictureBox
	Private tbxBval As System.Windows.Forms.TextBox
	Private label2 As System.Windows.Forms.Label
	Private tbxRes25deg As System.Windows.Forms.TextBox
	Private label1 As System.Windows.Forms.Label
	Private btnExit As System.Windows.Forms.Button
	Private btnCopy As System.Windows.Forms.Button
	Private btnGen As System.Windows.Forms.Button
End Class
